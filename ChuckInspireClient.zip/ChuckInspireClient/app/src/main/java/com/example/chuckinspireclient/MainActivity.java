package com.example.chuckinspireclient;

import androidx.appcompat.app.AppCompatActivity;


import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    Button btnGetQuote;
    TextView txtViewQuote;
    Switch swQuoteType;

    final static String ip = "10.0.2.2";
    final static int port = 5569;

    protected Socket socket;
    protected InputStream inputStream;
    protected OutputStream outputStream;
    protected ObjectOutputStream oOutputStream;
    ObjectInputStream oInputStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btnGetQuote = findViewById(R.id.btnGetQuote);
        final TextView txtViewQuote = findViewById(R.id.txtViewQuote);


        btnGetQuote.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            oOutputStream.writeObject(getClientRequest());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }) .start();

            }
        });

        startClient();


    }
    public void startClient(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    socket = new Socket(ip,port);
                    inputStream = socket.getInputStream();
                    outputStream = socket.getOutputStream();
                    oOutputStream = new ObjectOutputStream(outputStream);
                    oInputStream = new ObjectInputStream(inputStream);

                    oOutputStream.writeObject(getClientRequest());

                    while (true){
                        try {
                            final String serverStr = (String) oInputStream.readObject();
                            if(serverStr.equals("bye")){
                                Toast toast = Toast.makeText(getApplicationContext(), "Ending socket connection", Toast.LENGTH_LONG);
                                toast.show();
                                socket.close();
                                break;
                            }
                            else {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txtViewQuote = (TextView)MainActivity.this.findViewById(R.id.txtViewQuote);
                                        txtViewQuote.setText(serverStr);
                                    }
                                });
//                                try {
//                                    oOutputStream.writeObject("bye");
//                                }catch (Exception e){e.printStackTrace();}
                            }
                        }catch (Exception e) { e.printStackTrace(); }
                    }
                    startClient();
                }catch (Exception e) { e.printStackTrace(); }
            }
        }).start();
    }
    public String getClientRequest(){
        swQuoteType = (Switch) findViewById(R.id.swQuoteType);
        if (swQuoteType.isChecked()){
            return "chuck";
        }else{
            return "inspire";
        }
    }

}
