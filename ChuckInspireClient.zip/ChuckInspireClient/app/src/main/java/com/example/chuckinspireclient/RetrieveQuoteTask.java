//package com.example.chuckinspireclient;
//
//import android.os.AsyncTask;
//
//import java.io.IOException;
//
//class RetrieveQuoteTask extends AsyncTask <Void,Void,Void>{
//    MainActivity mainActivity;
//
//    @Override
//    protected Void doInBackground(Void... voids) {
//        String clientRequestStr = mainActivity.getClientRequest();
//        try {
//            mainActivity.oOutputStream.writeObject(clientRequestStr);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return null;
//
//    }
//}
