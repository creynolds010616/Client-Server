package Fragments;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.a_adevelopers.quotes.Model.Models;
import com.a_adevelopers.quotes.Model.QuoteAdapter;
import com.a_adevelopers.quotes.Model.SqlLite;
import com.a_adevelopers.quotes.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class SearchFragment extends Fragment {

    public SearchFragment() {
        // Required empty public constructor
    }

    private SQLiteDatabase database;
    public static QuoteAdapter timeAdapter;
    RecyclerView recyclerView;
    List<Models> modelLite = new ArrayList<>();
    Button search;
    EditText input;
    List<Models> searchlist = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate( R.layout.fragment_search, container, false );
        SqlLite dbHelper = new SqlLite( getContext() );
        database = dbHelper.getWritableDatabase();
        recyclerView = view.findViewById( R.id.recyler );
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        input = view.findViewById( R.id.input );
        search = view.findViewById( R.id.search );
        search.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // progressDialog.show();
                searchlist.clear();
                String sinput = input.getText().toString();
                if (sinput.isEmpty()) {
                    Toast.makeText( getContext(), "Search Something", Toast.LENGTH_SHORT ).show();

                } else {
                    //Function to search restaurant
                    search( sinput );
                }


            }
        } );
        return view;
    }
    private void search(final String query) {
        modelLite.clear();
        Cursor cursor = getAllItems();
        if (cursor != null && cursor.moveToNext()) {
            do {
                String ID = cursor.getString( cursor.getColumnIndex( "id" ) );
                String sub = cursor.getString( cursor.getColumnIndex( "quote" ) );
                String bookmark = cursor.getString( cursor.getColumnIndex( "bookmark" ) );
                if (sub.toLowerCase().trim().contains( query.toLowerCase().trim() )) {
                    modelLite.add( new Models(  sub, bookmark, ID ) );
                }



            }
            while (cursor.moveToNext());
            cursor.close();
            if (modelLite.size() == 0) {
                Toast.makeText( getContext(), "No Matched Quote !", Toast.LENGTH_SHORT ).show();
            } else {

                timeAdapter = new QuoteAdapter( getContext(), modelLite );
                // timeAdapter.notifyDataSetChanged();
                recyclerView.setAdapter( timeAdapter );
            }
        }


    }
    private Cursor getAllItems() {
        return database.query( "quote", null, null, null, null, null, "id DESC" );
    }
}
