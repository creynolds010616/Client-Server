package Fragments;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.a_adevelopers.quotes.Model.Models;
import com.a_adevelopers.quotes.Model.QuoteAdapter;
import com.a_adevelopers.quotes.Model.SqlLite;
import com.a_adevelopers.quotes.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    public HomeFragment() {
        // Required empty public constructor
    }

    RecyclerView recyclerView;
    private SQLiteDatabase database;
    List<Models> modelsList=new ArrayList<>(  );
    QuoteAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate( R.layout.fragment_home, container, false );
        SqlLite dbHelper = new SqlLite( getContext() );
        database = dbHelper.getWritableDatabase();
        recyclerView = view.findViewById( R.id.recycler );
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        refresh();
        return view;
    }

    public void refresh() {

        Cursor cursor = getAllItems();
        if (cursor != null && cursor.moveToNext()) {
            do {
                String ID = cursor.getString( cursor.getColumnIndex( "id" ) );
                String sub = cursor.getString( cursor.getColumnIndex( "quote" ) );
                String bookmark = cursor.getString( cursor.getColumnIndex( "bookmark" ) );



                modelsList.add( new Models(  sub, bookmark, ID ) );
            }
            while (cursor.moveToNext());
            cursor.close();
            if (modelsList.size() == 0) {
                Toast.makeText( getContext(), "No Data !", Toast.LENGTH_SHORT ).show();
            } else {


                adapter = new QuoteAdapter( getContext(), modelsList );
                // timeAdapter.notifyDataSetChanged();
                recyclerView.setAdapter( adapter );
            }
        }


       /* if (modelLite.size() == 0) {
            Toast.makeText( RecordActivity.this, "No Data !", Toast.LENGTH_SHORT ).show();
        } else {
            timeAdapter = new timeAdapter( RecordActivity.this, modelLite );
            timeAdapter.notifyDataSetChanged();
            recyclerView.setAdapter( timeAdapter );
           *//* ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new ItemTouchHelper.SimpleCallback( 0, ItemTouchHelper.LEFT ) {
                @Override
                public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {


                    return false;
                }

                @Override
                public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                    // Row is swiped from recycler view
                    // remove it from adapter
                    Model model = modelLite.get( viewHolder.getAdapterPosition() );
                    String ID = model.getId();
                    database.delete( "Watch", "id = ?", new String[]{String.valueOf( ID )} );
                    modelLite.remove( viewHolder.getAdapterPosition() );
                    timeAdapter.notifyDataSetChanged();
                    refresh();
                }

                @Override
                public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                    // view the background view
                    super.onChildDraw( c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive );
                }
            };

// attaching the touch helper to recycler view
            recyclerView.setLayoutManager( new LinearLayoutManager( RecordActivity.this ) );
            ItemTouchHelper itemTouchHelper = new ItemTouchHelper( itemTouchHelperCallback );
            itemTouchHelper.attachToRecyclerView( recyclerView );*//*
        }*/


    }
    private Cursor getAllItems() {
        return database.query( "quote", null, null, null, null, null, "id DESC" );
    }
}
