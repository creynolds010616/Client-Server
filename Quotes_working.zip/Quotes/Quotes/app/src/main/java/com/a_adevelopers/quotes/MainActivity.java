package com.a_adevelopers.quotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;

import com.a_adevelopers.quotes.Model.Models;
import com.a_adevelopers.quotes.Model.SqlLite;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

import Fragments.HomeFragment;
import Fragments.SearchFragment;
import Fragments.TopFragment;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        BottomNavigationView bottomNavigationView=findViewById( R.id.bottom);

        getSupportFragmentManager().beginTransaction().replace(R.id.fram,new HomeFragment()).commit();
        bottomNavigationView.setOnNavigationItemSelectedListener( new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId())
                {
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fram,new HomeFragment()).commit();

                        break;
                    case R.id.search:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fram,new SearchFragment()).commit();

                        break;
                    case R.id.top:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fram,new TopFragment()).commit();

                        break;

                }
                return true;

            }
        } );
    }
}
