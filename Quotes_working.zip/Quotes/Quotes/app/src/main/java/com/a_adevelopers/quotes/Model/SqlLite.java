package com.a_adevelopers.quotes.Model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SqlLite extends SQLiteOpenHelper {
    public  static  final String DATABASE_NAME="quote.dp";


    public SqlLite(@Nullable Context context) {
        super( context,DATABASE_NAME , null, 1 );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        final String sql="Create table quote ( id integer Primary key autoincrement,quote text , bookmark text  );";
        final String sql2="Create table top ( id integer Primary key autoincrement,quote text , bookmark text  );";

        db.execSQL( sql );
        db.execSQL( sql2 );



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL( "Drop table if exists Watch" );

    }
}
