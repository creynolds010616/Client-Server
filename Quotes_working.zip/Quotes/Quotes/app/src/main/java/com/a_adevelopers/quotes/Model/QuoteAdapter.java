package com.a_adevelopers.quotes.Model;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.a_adevelopers.quotes.R;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;

import java.util.List;

public class QuoteAdapter extends RecyclerView.Adapter<QuoteAdapter.ViewHolder> {

    private Context context;
    private Cursor cursor;
    private SQLiteDatabase database;
    List<Models> models;
    SqlLite sqlLite;



    public QuoteAdapter(Context context, List<Models> models )
    {
        this.context=context;
        this.models=models;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from( context );
        View view=inflater.inflate( R.layout.card ,parent,false);
        return new ViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        sqlLite=new SqlLite( context );
        Models model=models.get( position );
        final SqlLite dbHelper = new SqlLite( context );
        database = dbHelper.getWritableDatabase();




        final String ID=model.getId();
        final String sub=model.getText();
        final String book= model.getBookmark();
        holder.sub.setText( sub );
        if(book.equals( "true" ))
        {
            holder.book.setFavorite( true );
        }else {

            holder.book.setFavorite( false );
        }
        holder.book.setOnFavoriteChangeListener( new MaterialFavoriteButton.OnFavoriteChangeListener() {
            @Override
            public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                if(favorite){
                    SQLiteDatabase database = sqlLite.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put("quote",sub);
                    values.put( "bookmark","true" );
                    database.update( "quote",values,"id="+ID,null );
                    database.insert("top",null, values);
                    database.close();

                }else {

                    SQLiteDatabase database = sqlLite.getWritableDatabase();
                    database.delete("top", "quote" + "=?", new String[]{String.valueOf(sub)});
                    ContentValues values = new ContentValues();
                    values.put("quote",sub);
                    values.put( "bookmark","false" );
                    database.update( "quote",values,"id="+ID,null );
                    database.close();


                }
            }
        } );





    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{

        TextView sub;
        MaterialFavoriteButton book;


        public ViewHolder(@NonNull View itemView) {
            super( itemView );
            sub=itemView.findViewById( R.id.sub );
            book=itemView.findViewById( R.id.book );






        }
    }




    public void removeItem(int position) {
        models.remove(position);
        notifyItemRemoved(position);
    }
}
