package com.a_adevelopers.quotes.Model;

public class Models {
    String text;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getBookmark() {
        return bookmark;
    }

    public void setBookmark(String bookmark) {
        this.bookmark = bookmark;
    }

    public Models(String text, String bookmark,String id) {
        this.text = text;
        this.bookmark = bookmark;
        this.id=id;
    }

    String bookmark;
}
