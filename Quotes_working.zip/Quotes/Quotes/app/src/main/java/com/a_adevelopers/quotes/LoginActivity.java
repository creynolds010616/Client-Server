package com.a_adevelopers.quotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.a_adevelopers.quotes.Model.Models;
import com.a_adevelopers.quotes.Model.SqlLite;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    Button login;
    TextInputLayout email,pass;
    List<Models> models=new ArrayList<>(  );
    SqlLite sqlLite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login );
        sqlLite=new SqlLite( this );
        email=findViewById( R.id.email );
        pass=findViewById( R.id.pass );
        login=findViewById( R.id.login );
        login.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!pass.getEditText().getText().toString().isEmpty() && !email.getEditText().getText().toString().isEmpty()){
                    SharedPreferences sharedPreferences=getSharedPreferences( "quote",MODE_PRIVATE );
//                    if(!sharedPreferences.contains( "first" )){
//                        models.add( new Models(  "Anger is the ultimate destroyer of peace of mind","false" ,"0"));
//                        models.add( new Models(  "Do noy be afraid Be focused Be determine Be hopeful Be empowered","false","1" ));
//                        models.add( new Models(  "Children really brighten up a household They never turn the lights off","false","4" ));
//                        models.add( new Models(  "Appreciate those early influences what they have done for you","false","4" ));
//
//                        for(int i=0;i<models.size();i++){
//                            Models model=models.get( i );
//                            SQLiteDatabase database = sqlLite.getWritableDatabase();
//                            ContentValues values = new ContentValues();
//                            values.put("quote",model.getText());
//                            values.put( "bookmark",model.getBookmark() );
//                            database.insert("quote",null, values);
//                            database.close();
//
//                        }
                        sharedPreferences.edit().putString( "first" ,"false").apply();
                        startActivity( new Intent( LoginActivity.this,GetQuoteActivity.class ) );
                        finish();


//                    }else {
//
//                    }

                }else {
                    Toast.makeText( LoginActivity.this, "Something Missing !", Toast.LENGTH_SHORT ).show();
                }
            }
        } );
    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences sharedPreferences=getSharedPreferences( "quote",MODE_PRIVATE );
        if(sharedPreferences.contains( "first" )){{
            startActivity( new Intent( LoginActivity.this,GetQuoteActivity.class ) );
            finish();
        }}
    }
}
