package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Switch;
import android.widget.TextView;

import com.example.chuckinspireandroid.R;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    Socket socket;
    InputStream inputStream;
    OutputStream outputStream;
    ObjectInputStream oInputStream;
    ObjectOutputStream oOutputStream;


    public TextView txtViewQuote;
    public Button btnGetQuote;
    public CheckBox cbQuoteType;

    String ip;
    int port;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtViewQuote = (TextView)findViewById(R.id.txtViewQuote);
        btnGetQuote = (Button) findViewById(R.id.btnGetQuote);
        cbQuoteType = (CheckBox) findViewById(R.id.cbQuoteType); // if switched , get Chuck.

        ip = "127.0.0.1";
        port = 5569;
        startClient();
        btnGetQuote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (cbQuoteType.isChecked()){
                        oOutputStream.writeObject("chuck");
                        oOutputStream.flush();
                    }
                    else{
                        oOutputStream.writeObject("inspire");
                        oOutputStream.flush();
                    }
                }catch (Exception e){
                    e.getStackTrace();
                }
            }
        });

    }
    protected void startClient(){
        new Thread( new Runnable(){
            public void run(){
                try{
                    socket = new Socket(ip, port); // 13.65.30.220 , 5555

                    outputStream = socket.getOutputStream();
                    inputStream = socket.getInputStream();
                    oOutputStream = new ObjectOutputStream(outputStream);
                    oInputStream = new ObjectInputStream(inputStream);

                    while(true){
                        String serverMessageStr = (String)oInputStream.readObject();
                        txtViewQuote.setText(serverMessageStr);
                        //Thread.sleep(300); // ms
                    }
                }
                catch(Exception e){
                    e.getStackTrace();
                }
            }
        }).start();
    }


}
