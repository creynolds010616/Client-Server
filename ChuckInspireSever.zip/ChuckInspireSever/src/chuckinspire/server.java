//package chuckinspire;
//
//import java.io.File;
//import java.io.IOException;
//import java.sql.*;
//import java.util.Scanner;
//
//public class server {
//    public static void main(String[] args){
//        
//    }
//    private class Chuck{
//        private String quote;
//        
//        public Chuck(String quote){
//            this.quote = quote;
//        }
//        public String getQuote(){
//            return quote;
//        }
//        public void setQuote(String quote){
//            this.quote = quote;
//        }
//    }
//    private class Inspire{
//        private String quote;
//        private String author;
//        private String category;
//        
//        public Inspire(String quote, String author, String category){
//            this.quote = quote;
//            this.author = author;
//            this.category = category;
//        }
//        public void setQuote(String quote){
//            this.quote = quote;
//        }
//        public void setAuthor(String author){
//            this.author = author;
//        }
//        public void setCategory(String category){
//            this.category = category;
//        }
//    }
//}
//
//
